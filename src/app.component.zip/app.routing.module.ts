import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormComponent } from './components/form/form.component';
import { PainelComponent } from './components/painel/painel.component';

const routes: Routes = [
  { path: '', component: PainelComponent }, // Página inicial
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
