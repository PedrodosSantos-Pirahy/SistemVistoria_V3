import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { FormComponent } from './components/form/form.component';
import { PainelComponent } from './components/painel/painel.component';
import { AppRoutingModule } from '../src/app.routing.module';

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    PainelComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
