import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { CommonModule } from '@angular/common';

export interface Agendamento {
  id: string;
  placa: string;
  vistoriador: string;
  inicio: Date;
  duracao: 15 | 30 | 45 | 60;
}

@Component({
  selector: 'app-agendamento',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './agendamento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AgendamentoComponent {

  error = signal<string | null>(null);

  form!: FormGroup;

  // MOCK LOCAL
  private agendamentos: Agendamento[] = [];

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      placa: ['', Validators.required],
      vistoriador: ['', Validators.required],
      inicio: ['', Validators.required],
      duracao: [30 as 15 | 30 | 45 | 60, Validators.required]
    });
  }

  salvar(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const inicio = new Date(this.form.value.inicio);
    const duracao = this.form.value.duracao;

    const novo: Agendamento = {
      id: crypto.randomUUID(),
      placa: this.form.value.placa,
      vistoriador: this.form.value.vistoriador,
      inicio,
      duracao
    };

    if (!this.podeAgendar(novo)) {
      this.error.set('Já existem 3 vistorias nesse horário.');
      return;
    }

    this.agendamentos.push(novo);
    this.form.reset({ duracao: 30 });
    this.error.set(null);
  }

  private podeAgendar(novo: Agendamento): boolean {
    const inicio = novo.inicio;
    const fim = new Date(inicio.getTime() + novo.duracao * 60000);

    const blocos = this.blocos15(inicio, fim);

    for (const bloco of blocos) {
      const simultaneos = this.agendamentos.filter(a => {
        const aInicio = new Date(a.inicio);
        const aFim = new Date(aInicio.getTime() + a.duracao * 60000);
        return bloco >= aInicio && bloco < aFim;
      });

      if (simultaneos.length >= 3) {
        return false;
      }
    }

    return true;
  }

  private blocos15(inicio: Date, fim: Date): Date[] {
    const blocos: Date[] = [];
    let atual = new Date(inicio);

    while (atual < fim) {
      blocos.push(new Date(atual));
      atual.setMinutes(atual.getMinutes() + 15);
    }

    return blocos;
  }
}
