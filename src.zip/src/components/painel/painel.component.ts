import { Component, ChangeDetectionStrategy, output, signal, OnInit } from '@angular/core';
import { Router } from '@angular/router';

/**
 * Interface simples para representar
 * uma vistoria pendente retornada pela API
 */
interface Inspection {
  placa: string;
}

@Component({
  selector: 'app-painel',
  standalone: true,
  templateUrl: './painel.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PainelComponent implements OnInit {

  /**
   * Lista de vistorias pendentes exibidas no painel
   * Utiliza signal para melhor performance com OnPush
   */
  readonly inspections = signal<Inspection[]>([]);

  /**
   * Controla o estado de carregamento da tela
   */
  readonly loading = signal<boolean>(true);

  /**
   * Armazena mensagem de erro, se houver falha na API
   */
  readonly error = signal<string | null>(null);

  /**
   * Output já existente no componente.
   * NÃO foi removido para não quebrar integrações existentes.
   */
  readonly inspectionSelected = output<string>();

  /* =========================================================
     ESTADOS ADICIONADOS PARA O MODAL (NÃO EXISTIAM ANTES)
     ========================================================= */

  /**
   * Guarda a placa selecionada no painel
   * enquanto o modal de decisão está aberto
   */
  selectedPlaca = signal<string | null>(null);

  /**
   * Controla a exibição do modal de confirmação
   */
  showDecisionModal = signal<boolean>(false);

  /**
   * Armazena a resposta do usuário no modal:
   * 'sim'  -> realizar vistoria
   * 'nao'  -> cancelar antecipadamente
   */
  resposta: 'sim' | 'nao' | null = null;

  /**
   * Motivo do cancelamento (obrigatório se resposta === 'nao')
   */
  motivo: string = '';

  /**
   * Router usado apenas quando o usuário
   * confirma que deseja realizar a vistoria
   */
  constructor(private router: Router) {}

  /**
   * Ciclo de vida do Angular
   * Ao iniciar o painel, busca as vistorias pendentes
   */
  ngOnInit(): void {
    this.fetchInspections();
  }

  /**
   * Busca as vistorias pendentes no backend (Python)
   * Esse método NÃO foi alterado, apenas comentado
   */
  async fetchInspections(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);

    try {
      // Chamada à API local que retorna as vistorias pendentes
      const response = await fetch("http://192.168.53.193:5000/pendencias", {
        method: 'GET'
      });

      // Se o backend responder erro HTTP
      if (!response.ok) {
        throw new Error(`Erro de servidor: ${response.statusText} (${response.status})`);
      }

      // Converte a resposta para JSON
      const data = await response.json();

      // Espera-se que a API retorne um array de placas
      const placas = data.pendentes;

      // Validação defensiva do retorno
      if (!Array.isArray(placas)) {
        console.error('A resposta da API não é um array válido:', placas);
        throw new Error('Formato de dados inesperado da API. A lista de vistorias não foi encontrada.');
      }

      /**
       * Converte o array simples de strings
       * em objetos do tipo Inspection
       */
      const parsedInspections: Inspection[] = placas
        .map((placa: unknown) => {
          if (typeof placa !== 'string' || !placa) {
            console.warn(`Item de vistoria inválido ignorado:`, placa);
            return null;
          }
          return { placa };
        })
        .filter((item): item is Inspection => item !== null);

      // Atualiza o estado do painel
      this.inspections.set(parsedInspections);

    } catch (err) {
      console.error('Erro ao buscar dados da API:', err);

      let errorMessage = 'Não foi possível carregar as vistorias.';
      if (err instanceof Error) {
        errorMessage = `Não foi possível conectar a API na rede. Detalhes: ${err.message}`;
      }

      this.error.set(errorMessage);
      this.inspections.set([]);
    } finally {
      this.loading.set(false);
    }
  }

/**
 * Clique na vistoria
 * Apenas abre o modal
 */
selectInspection(placa: string): void {
  this.selectedPlaca.set(placa);
  this.showDecisionModal.set(true);
}

/**
 * Fecha o modal sem ação
 */
fecharModal(): void {
  this.showDecisionModal.set(false);
}

/**
 * Confirma e AVANÇA PARA O FORMULÁRIO
 * (exatamente como o código antigo fazia)
 */
confirmar(): void {
  const placa = this.selectedPlaca();
  if (!placa) return;

  // Fecha o modal
  this.showDecisionModal.set(false);

  // 🔥 EMITE A PLACA PARA O COMPONENTE PAI
  this.inspectionSelected.emit(placa);
}}
